import au.edu.uts.ap.javafx.*;
import javafx.application.Application;
import model.Kiosk;
import javafx.stage.Stage;

public class KioskApplication extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {

        ViewLoader.showStage(new Kiosk(), "/view/Kiosk.fxml", "Game Kiosk - Main Menu", stage);
    }
}
