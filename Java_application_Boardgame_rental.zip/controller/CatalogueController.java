package controller;

import au.edu.uts.ap.javafx.Controller;
import au.edu.uts.ap.javafx.ViewLoader;
import javafx.event.ActionEvent;
import javafx.stage.Stage;
import model.Catalogue;
import java.io.IOException;

public class CatalogueController extends Controller<Catalogue> {

    public void showAllGames(ActionEvent e) throws IOException {
        ViewLoader.showStage(model, "/view/ShowAllGames.fxml", "All Games", new Stage());
    }

    public void showAvailableGames(ActionEvent e) throws IOException {
        ViewLoader.showStage(model, "/view/ShowAvailableGames.fxml", "Available Games", new Stage());
    }

    public void showGamesByGenre(ActionEvent e) throws IOException {
        ViewLoader.showStage(model, "/view/ShowGamesByGenre.fxml", "Games by Genre", new Stage());
    }

    public void showGamesByYear(ActionEvent e) throws IOException {
        ViewLoader.showStage(model, "/view/ShowGamesByYear.fxml", "Games by Year", new Stage());
    }

    public void rentGame(ActionEvent e) throws IOException {
        ViewLoader.showStage(model, "/view/RentGame.fxml", "Rent Game", new Stage());
    }

    public void returnGame(ActionEvent e) throws IOException {
        ViewLoader.showStage(model, "/view/ReturnGame.fxml", "Return Game", new Stage());
    }

    public void exit(ActionEvent e) {
        stage.close();
    }
}
