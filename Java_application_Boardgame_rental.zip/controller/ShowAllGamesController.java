package controller;

import au.edu.uts.ap.javafx.Controller;
import javafx.event.ActionEvent;
import model.Catalogue;

public class ShowAllGamesController  extends Controller<Catalogue> {
    KioskController kioskController;

    public Catalogue getCatalogue() {
        return kioskController.catalogue;
    }
    
    public void exit(ActionEvent e) {
        stage.close();
    }
}
