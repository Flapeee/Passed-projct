package controller;

import au.edu.uts.ap.javafx.Controller;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import model.Catalogue;
import model.Game;

public class ShowAvailableGamesController extends Controller<Catalogue> {
    KioskController kioskController;

    public Catalogue getCatalogue() {
        return kioskController.catalogue;
    }
    
    @FXML 
    private ListView<Game> GameALv;
    
    public ObservableList<Game> getAvailableGame() {
        return getCatalogue().getAvailableGames();
    }
    
    public void display(){
        GameALv.setItems(getAvailableGame());
    }
        
    public void exit(ActionEvent e) {
        stage.close();
    }
}
