package controller;

import au.edu.uts.ap.javafx.Controller;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import model.Game;
import model.Catalogue;
import model.Customer;
import model.Kiosk;


public class CustomerRecordController extends Controller<Kiosk> {
    KioskController kioskController;

    public Kiosk getKiosk() {
        return kioskController.kiosk;
    }
    
     public Catalogue getCatalogue() {
        return kioskController.catalogue;
    }

    @FXML
    private TextField IDTf;

    @FXML
    private TableView<Game> currentlyRentedLv;

    @FXML
    private TableView<Game> rentingHistoryLv;

    @FXML
    private Button showRecordBt;
    
    @FXML 
    private Text resultText;

    public int getIDTf() {
        return Integer.parseInt(IDTf.getText());
    }

    public Customer currentCustomer() {
        return getCatalogue().getCustomer(getIDTf());
    }

    public ObservableList<Game> getCurrentlyRented(){
        return currentCustomer().currentlyRented();
    }

    public ObservableList<Game> getRenttingHistory() {
        return currentCustomer().rentingHistory();
    }

    public void showRecords(ActionEvent e) {
        if (getKiosk().getCustomers().contains(currentCustomer())) {
            //verify is this guy in our list
            currentlyRentedLv.setItems(getCurrentlyRented());
            rentingHistoryLv.setItems(getRenttingHistory());
            resultText.setText(currentCustomer().toString());
        }
        else{
            resultText.setText("Customer does not exsit");
        }
    }


    public void exit(ActionEvent e) {
        stage.close();
    }

    public void initialize() {
        IDTf.textProperty().addListener((observable, oldValue, newValue) -> {
            showRecordBt.setDisable(!newValue.matches("[0123456789]+"));
        });
    }
}
