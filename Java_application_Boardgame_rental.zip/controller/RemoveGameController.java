package controller;

import au.edu.uts.ap.javafx.Controller;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableView;
import model.Catalogue;
import model.Game;
import model.Kiosk;

public class RemoveGameController extends Controller<Kiosk> {

  public Catalogue getCatalogue() {
    return KioskController.catalogue;
  }

  @FXML
  private TableView<Game> gameTv;

  @FXML
  public void handleRemove(ActionEvent event) {
    Game game = gameTv.getSelectionModel().getSelectedItem();
    getCatalogue().removeGame(game);
    gameTv.setItems(getCatalogue().getAllGames());
  }

  @FXML
  private void initialize() {
    gameTv.setItems(getCatalogue().getAllGames());
  }

  public void exit(ActionEvent e) {
    stage.close();
  }
}