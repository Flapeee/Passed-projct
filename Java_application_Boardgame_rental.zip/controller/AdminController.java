package controller;

import au.edu.uts.ap.javafx.Controller;
import au.edu.uts.ap.javafx.ViewLoader;
import javafx.event.ActionEvent;
import javafx.stage.Stage;
import java.io.IOException;
import model.Kiosk;

public class AdminController extends Controller<Kiosk> {
    KioskController kioskController;
    
    public Kiosk getKiosk(){
        return KioskController.kiosk;
    }
    
    public void showAllCustomers(ActionEvent e) throws IOException {
        ViewLoader.showStage(model, "/view/ShowAllCustomers.fxml", "Show all Customer", new Stage());
    }

    public void addCustomer(ActionEvent e) throws IOException {
        ViewLoader.showStage(model, "/view/AddCustomer.fxml", "Add Customer", new Stage());
    }

    public void removeCustomer(ActionEvent e) throws IOException {
        ViewLoader.showStage(model, "/view/RemoveCustomer.fxml", "Remove Customer", new Stage());
    }
    
    public void showAllGames(ActionEvent e) throws IOException {
        ViewLoader.showStage(model, "/view/ShowAllGames.fxml", "Show All Game", new Stage());
    }
    
    public void addGame (ActionEvent e) throws IOException {
        ViewLoader.showStage(model, "/view/AddGame.fxml", "Add Game", new Stage());
    }
    
    public void removeGame(ActionEvent e) throws IOException {
        ViewLoader.showStage(model, "/view/RemoveGame.fxml", "Remove Game", new Stage());
    }
    
    public void exit(ActionEvent e) {
        stage.close();
    }
}