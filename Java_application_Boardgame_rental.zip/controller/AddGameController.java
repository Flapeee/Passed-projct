
package controller;

import au.edu.uts.ap.javafx.Controller;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import model.Catalogue;


public class AddGameController extends Controller<Catalogue> {
    KioskController kioskController;

    public Catalogue getCatalogue(){
        return kioskController.catalogue;
    }

    @FXML 
    private TextField titleTf;
    
    @FXML 
    private TextField yearTf;
    
    @FXML 
    private TextField genreTf;
    
    @FXML 
    private TextField priceTf;
    
    @FXML 
    private Button addGameBt;
    
    @FXML 
    private Text resultText;
    
    
    public String getTitle(){
        return titleTf.getText();
    }

    public int getYear(){
        return Integer.parseInt(yearTf.getText());
    }

    public String getGenre(){
        return genreTf.getText();
    }
    
     public int getPrice(){
        return Integer.parseInt(priceTf.getText());
    }

    public void exit(ActionEvent e) {
        stage.close();
    }

    @FXML public void handlleAddGame(ActionEvent actionEvent) {
        getCatalogue().addGame(getTitle(),getYear(),getGenre(),getPrice());
        titleTf.setText("");
        yearTf.setText("");
        genreTf.setText("");
        priceTf.setText("");
        resultText.setText("Game added to Catalogue");
    }

    public void initialize(){
        addGameBt.textProperty().addListener((observable, oldValue, newValue  )->{
            addGameBt.setDisable(!newValue.matches("[0123456789]+"));
        });
    }
} 