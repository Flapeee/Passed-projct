package controller;

import au.edu.uts.ap.javafx.Controller;
import javafx.event.ActionEvent;
import model.Kiosk;

public class ShowAllCustomersController extends Controller<Kiosk> {
    KioskController kioskController;

    public Kiosk getKiosk() {
        return kioskController.kiosk;
    }

    public void exit(ActionEvent e) {
        stage.close();
    }
}