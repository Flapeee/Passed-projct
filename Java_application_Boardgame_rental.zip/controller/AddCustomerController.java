package controller;

import au.edu.uts.ap.javafx.Controller;
import java.util.Iterator;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import model.Catalogue;
import model.Customer;
import model.Kiosk;


public class AddCustomerController extends Controller<Kiosk> {

  KioskController kioskController;

  public Kiosk getKiosk() {
    return kioskController.kiosk;
  }

  public Catalogue getCatalogue() {
    return kioskController.catalogue;
  }

  @FXML
  private TextField idTf;
  
  @FXML
  private TextField nameTf;
  
  @FXML
  private TextField balanceTf;
  
  @FXML
  private Button addCustomerBtn;
  
  @FXML
  private Text resultText;

  public int getID() {
    return Integer.parseInt(idTf.getText());
    }

  public String getName() {
    return nameTf.getText();
  }

  public int getBalance() {
    return Integer.parseInt(balanceTf.getText());
  }

  public void exit(ActionEvent e) {
    stage.close();
  }

  public ObservableList<Customer> getCustomers() {
    return getKiosk().getCustomers();
  }


  @FXML
  public void handlleAddCustomer(ActionEvent actionEvent) {
    Iterator<Customer> it = getCustomers().iterator();
    while (it.hasNext()) {
      Customer customer = it.next();
      if (customer.getId() == getID()) {
        resultText.setText("ID is not valid");
        return;
      }
      else if(getBalance() < 0){
        resultText.setText("Amount must be equal or large than 0");
        return;
        }
    }
    getKiosk().addCustomer(getID(), getName(), getBalance());
    idTf.setText("");
    nameTf.setText("");
    balanceTf.setText("");
    resultText.setText("Customer added to Kiosk");
  }


  public void initialize() {
    idTf.textProperty().addListener((observable, oldValue, newValue) -> {
      addCustomerBtn.setDisable(!newValue.matches("[0123456789]+"));
    });
  }
}

