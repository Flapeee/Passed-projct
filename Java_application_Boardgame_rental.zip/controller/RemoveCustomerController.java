package controller;

import au.edu.uts.ap.javafx.Controller;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableView;
import model.Customer;
import model.Kiosk;

public class RemoveCustomerController extends Controller<Kiosk> {

  public Kiosk getKiosk() {
    return KioskController.kiosk;
  }

  @FXML
  private TableView<Customer> allCustomerLv;
  
  @FXML
  public void handleRemove(ActionEvent actionEvent) {
    int index = allCustomerLv.getSelectionModel().getSelectedIndex();
    allCustomerLv.getItems().remove(index);
  }

  public void exit(ActionEvent e) {
    stage.close();
  }
}