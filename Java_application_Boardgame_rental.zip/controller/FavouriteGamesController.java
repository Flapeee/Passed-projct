package controller;

import au.edu.uts.ap.javafx.Controller;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import model.Catalogue;
import model.Customer;
import model.Game;
import model.Kiosk;

public class FavouriteGamesController extends Controller<Kiosk> {

  public Kiosk getKiosk() {
    return KioskController.kiosk;
  }

  public Catalogue getCatalogue() {
    return KioskController.catalogue;
  }

  @FXML
  private TextField IDTf;

  @FXML
  private TableView<Game> favGameALv;

  @FXML
  private Button showFavouritesBt;
  
  @FXML
  private Text resultText;

  public int getIDTf() {
    return Integer.parseInt(IDTf.getText());
  }

  public Customer currentCustomer() {
    return getCatalogue().getCustomer(getIDTf());
  }

  public ObservableList<Game> getFavGame() {
    return currentCustomer().favouriteGames();
  }

  public void showFavourites(ActionEvent e) {
    if (getKiosk().getCustomers().contains(currentCustomer())) {
      //verify is this guy in list?
      favGameALv.setItems(getFavGame());
      resultText.setText("");
    }
    else{
      resultText.setText("Customer does not exsit");
    }
  }

  public void exit(ActionEvent e) {
    stage.close();
  }

  public void initialize() {
    IDTf.textProperty().addListener((observable, oldValue, newValue) -> {
      showFavouritesBt.setDisable(!newValue.matches("[0123456789]+"));
    });
  }
}