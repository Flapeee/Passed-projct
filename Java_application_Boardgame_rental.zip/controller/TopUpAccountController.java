package controller;

import au.edu.uts.ap.javafx.Controller;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import model.Kiosk;
import model.Customer;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import model.Catalogue;

public class TopUpAccountController  extends Controller<Kiosk> {
    KioskController kioskController;

 public Catalogue getCatalogue() {
        return kioskController.catalogue;
    }
 
  public Kiosk getKiosk() {
        return kioskController.kiosk;
    }

    @FXML 
    private TextField idTf;
    
    @FXML 
    private TextField amountTf;
    
    @FXML 
    private Button topUpBtn;
    
    @FXML 
    private Text resultText;
  
    public int getID(){
        return Integer.parseInt(idTf.getText());
    }

    public int getAmount(){
        return Integer.parseInt(amountTf.getText());
    }
    
    public void exit(ActionEvent e) {
        stage.close();
    }
    
    public Customer getCurrentCustomer(){
        return getCatalogue().getCustomer(getID());
    }
      
    @FXML public void handlleTopUp(ActionEvent actionEvent) {
        if (getKiosk().getCustomers().contains(getCurrentCustomer()) && getAmount() >= 0){
        getKiosk().topUpAccount(getCurrentCustomer(),getAmount());
        idTf.setText("");
        amountTf.setText("");
        resultText.setText("Transaction Complete");
        }
        else if(getAmount() < 0){
        resultText.setText("Top-up amount must be large than 0");
        }
        else{
        resultText.setText("Customer dose not exsit");
        }
    }
    
    public void initialize(){
        idTf.textProperty().addListener((observable, oldValue, newValue  )->{
            topUpBtn.setDisable(!newValue.matches("[0123456789]+"));
        }); 
    }
}