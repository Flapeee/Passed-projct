package controller;

import au.edu.uts.ap.javafx.Controller;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.TableView;
import model.Catalogue;
import model.Game;
import model.Kiosk;

public class ShowGamesByYearController extends Controller<Kiosk> {

    public Catalogue getCatalogue() {
        return KioskController.catalogue;
    }

    @FXML
    private TableView<Game> gameTv;
    
    @FXML
    private ListView<Integer> years;

    public void display(ActionEvent e) {
        int year = years.getSelectionModel().getSelectedItem();
        ObservableList<Game> games = getCatalogue().getGamesByYear(year);
        gameTv.setItems(games);
    }

    public void exit(ActionEvent e) {
        stage.close();
    }
}
