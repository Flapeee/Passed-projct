package controller;
import au.edu.uts.ap.javafx.Controller;
import au.edu.uts.ap.javafx.ViewLoader;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.stage.Stage;
import model.Kiosk;
import model.Catalogue;
import java.io.IOException;

public class KioskController extends Controller<Kiosk> {
    
    //add a new kiosk
    public static Kiosk kiosk = new Kiosk();
    
    //add a new catalogue
    public static Catalogue catalogue = new Catalogue(kiosk);
  
    @FXML
    public void initialize() {
    }

    public final Kiosk getKiosk() {
        return model;
    }
  
    public void exploreCatalogue(ActionEvent e) throws IOException {
        ViewLoader.showStage(catalogue, "/view/Catalogue.fxml", "Catalogue", new Stage());
    }

    public void customerRecord(ActionEvent e) throws IOException {
        ViewLoader.showStage(model, "/view/CustomerRecord.fxml", "CustomerRecord", new Stage());
    }

    public void topUpAccount(ActionEvent e) throws IOException {
        ViewLoader.showStage(model, "/view/TopUpAccount.fxml", "TopUp", new Stage());
    }
    
    public void favouriteGames(ActionEvent e) throws IOException {
        ViewLoader.showStage(model, "/view/FavouriteGames.fxml", "FavouritGames", new Stage());
    }

    public void admin(ActionEvent e) throws IOException {
        ViewLoader.showStage(catalogue, "/view/Admin.fxml", "Administration Menu", new Stage());
    }

    public void exit(ActionEvent e) {
        stage.close();
    }

}
