package controller;

import au.edu.uts.ap.javafx.Controller;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import model.Catalogue;
import model.Customer;
import model.Game;
import model.Kiosk;

public class ReturnGameController extends Controller<Kiosk> {

  public Kiosk getKiosk() {
    return KioskController.kiosk;
  }

  public Catalogue getCatalogue() {
    return KioskController.catalogue;
  }

  @FXML
  private TextField IDTf;

  @FXML
  private TableView<Game> gameTv;

  @FXML
  private Button selectBt;

  @FXML
  private Button returnBt;

  public int getIDTf() {
    return Integer.parseInt(IDTf.getText());
  }

  public Customer currentCustomer() {
    return getCatalogue().getCustomer(getIDTf());
  }

  public void select(ActionEvent e) {
    if (getKiosk().getCustomers().contains(currentCustomer())) {
      //if ture
      gameTv.setItems(currentCustomer().currentlyRented());
    }
  }

  public Game getSelectGame() {
    return gameTv.getSelectionModel().getSelectedItem();
  }

  public void returnGame(ActionEvent e) {
    //有输入的值
    getCatalogue().returnGameFromCustomer(getSelectGame(), currentCustomer());
  }

  public void exit(ActionEvent e) {
    stage.close();
  }

  public void initialize() {
    IDTf.textProperty().addListener((observable, oldValue, newValue) -> {
      selectBt.setDisable(!newValue.matches("[0123456789]+"));
      returnBt.setDisable(!newValue.matches("[0123456789]+"));
    });
  }
}