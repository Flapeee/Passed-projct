package controller;

import au.edu.uts.ap.javafx.Controller;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import model.Catalogue;
import model.Customer;
import model.Game;
import model.Kiosk;

public class RentGameController extends Controller<Kiosk> {

  public Kiosk getKiosk() {
    return KioskController.kiosk;
  }

  public Catalogue getCatalogue() {
    return KioskController.catalogue;
  }

  @FXML
  private TextField IDTf;

  @FXML
  private TableView<Game> gameTv;

  @FXML
  private Button selectBt;

  @FXML
  private Button RentBt;

  @FXML
  private Text resultText;

  public int getIDTf() {
    return Integer.parseInt(IDTf.getText());
  }

  public Customer currentCustomer() {
    return getCatalogue().getCustomer(getIDTf());
  }

  public ObservableList<Game> getAvailableGame() {
    return getCatalogue().getAvailableGames();
  }

  public void verify(ActionEvent e) {
    if (getKiosk().getCustomers().contains(currentCustomer())) {
      //verify is this guy in list?
      resultText.setText("");
      gameTv.setItems(getAvailableGame());
    } else {
      resultText.setText("Customer not exsit");
      gameTv.setItems(null);
    }
  }

  private Game getSelectGame() {
    return gameTv.getSelectionModel().getSelectedItem();
  }

  public void rentGame(ActionEvent e) {
    boolean rentFlag = getCatalogue().rentGameToCustomer(getSelectGame(), currentCustomer());
    if(!rentFlag) {
      resultText.setText("Not sufficient funds");
    }else{
      resultText.setText("Game Rented");  
    }
    
  }

  public void exit(ActionEvent e) {
    stage.close();
  }

  public void initialize() {
    IDTf.textProperty().addListener((observable, oldValue, newValue) -> {
      selectBt.setDisable(!newValue.matches("[0123456789]+"));
      RentBt.setDisable(!newValue.matches("[0123456789]+"));
    });
  }
}