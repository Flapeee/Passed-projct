import sys
import pandas as pd
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
from surprise import Dataset, Reader, SVD, accuracy
from surprise.model_selection import train_test_split

# 读取数据文件
u_data = pd.read_csv(r'C:\Users\12717\Desktop\ml-100k\u.data', sep='\t', names=['user_id', 'item_id', 'rating', 'timestamp'])
u_item = pd.read_csv(r'C:\Users\12717\Desktop\ml-100k\u.item', sep='|', encoding='latin-1', 
                     names=['movie_id', 'movie_title', 'release_date', 'video_release_date', 'IMDb_URL', 
                            'unknown', 'Action', 'Adventure', 'Animation', 'Children', 'Comedy', 'Crime', 
                            'Documentary', 'Drama', 'Fantasy', 'Film-Noir', 'Horror', 'Musical', 'Mystery', 
                            'Romance', 'Sci-Fi', 'Thriller', 'War', 'Western'])

# 合并两个数据集，方便后续分析
data_merged = pd.merge(u_data, u_item, left_on='item_id', right_on='movie_id')

# 打印一共有多少个用户和电影
num_users = u_data['user_id'].nunique()
num_movies = u_item['movie_id'].nunique()
print(f"总共有 {num_users} 个用户")
print(f"总共有 {num_movies} 部电影")

# 使用Surprise库来读取数据
reader = Reader(rating_scale=(1, 5))
data = Dataset.load_from_df(data_merged[['user_id', 'item_id', 'rating']], reader)

# 划分训练集和测试集
trainset, testset = train_test_split(data, test_size=0.2)

# 使用SVD算法进行训练
svd = SVD()
svd.fit(trainset)

# 在测试集上进行预测
predictions = svd.test(testset)

# 计算RMSE
rmse = accuracy.rmse(predictions)
print(f'RMSE: {rmse}')

# 计算召回率的函数
def recall_at_k(predictions, k=10, threshold=3.5):
    user_est_true = {}
    for uid, _, true_r, est, _ in predictions:
        if true_r >= threshold:
            user_est_true.setdefault(uid, []).append((est, true_r))

    recall = 0
    for uid, user_ratings in user_est_true.items():
        user_ratings.sort(key=lambda x: x[0], reverse=True)
        n_rel_and_rec_k = sum((true_r >= threshold) for (_, true_r) in user_ratings[:k])
        n_rel = sum((true_r >= threshold) for (_, true_r) in user_ratings)

        if n_rel != 0:
            recall += n_rel_and_rec_k / n_rel

    recall /= len(user_est_true)
    return recall

recall = recall_at_k(predictions)
print(f'Recall: {recall}')

# 推荐电影的函数
def recommend_movies(user_id, svd, u_item, n_recommendations=5):
    movie_ids = u_item['movie_id'].tolist()
    user_rated_movies = u_data[u_data['user_id'] == user_id]['item_id'].tolist()
    
    predictions = [svd.predict(user_id, movie_id) for movie_id in movie_ids if movie_id not in user_rated_movies]
    top_predictions = sorted(predictions, key=lambda x: x.est, reverse=True)[:n_recommendations]
    
    recommended_movies = [(u_item[u_item['movie_id'] == pred.iid]['movie_title'].values[0], pred.est) for pred in top_predictions]
    
    return recommended_movies

# 检查用户ID输入
if len(sys.argv) > 1 and sys.argv[1].isdigit():
    user_id = int(sys.argv[1])
else:
    user_id = input("请输入要查看的用户ID: ")
    if not user_id.isdigit():
        print("无效的用户ID")
        exit(1)
    user_id = int(user_id)

# 获取推荐结果并打印
recommended_movies = recommend_movies(user_id, svd, u_item, n_recommendations=5)
print(f"推荐给用户ID {user_id} 的电影及评分：")
for movie, rating in recommended_movies:
    print(f"{movie}: {rating}")

# 计算用户相似度的函数
def user_similarity(user1, user2, u_data):
    user1_ratings = u_data[u_data['user_id'] == user1][['item_id', 'rating']]
    user2_ratings = u_data[u_data['user_id'] == user2][['item_id', 'rating']]
    
    common_items = pd.merge(user1_ratings, user2_ratings, on='item_id')
    if len(common_items) == 0:
        return 0
    
    user1_ratings = common_items['rating_x']
    user2_ratings = common_items['rating_y']
    
    return np.corrcoef(user1_ratings, user2_ratings)[0, 1]

# 创建用户社交网络图的函数
def create_social_network(user_id, u_data, n_neighbors=5):
    G = nx.Graph()
    
    user_movies = u_data[u_data['user_id'] == user_id]['item_id'].tolist()
    similar_users = u_data[u_data['item_id'].isin(user_movies) & (u_data['user_id'] != user_id)]['user_id'].value_counts().head(n_neighbors).index.tolist()
    
    G.add_node(user_id)
    for neighbor in similar_users:
        similarity = user_similarity(user_id, neighbor, u_data)
        G.add_node(neighbor)
        G.add_edge(user_id, neighbor, weight=similarity)
    
    return G

# 生成并绘制社交网络图
G = create_social_network(user_id, u_data)
pos = nx.spring_layout(G)
plt.figure(figsize=(10, 10))
nx.draw(G, pos, with_labels=True, node_color='skyblue', node_size=3000, edge_color='gray', linewidths=1, font_size=15)
edge_labels = nx.get_edge_attributes(G, 'weight')
nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels)

plt.title(f"用户ID {user_id} 的社交网络图")
plt.show()
