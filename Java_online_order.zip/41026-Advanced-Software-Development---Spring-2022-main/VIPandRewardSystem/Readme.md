F109
VIP Management
Users can purchase VIP status by purchasing a paid membership. There are various types of membership available at different price points including, hidden menu services, and priority restaurant reservations. At the same time, the restaurant also offers a wide range of additional services, gifts and events for all VIP customers.
Songwen Hua
F110
Rewards System Management
Users can register for membership and are automatically provided with a member ID. Users will receive a voucher on their first registration and will receive points for each subsequent purchase, which can be redeemed for vouchers. You can use the coupons when you make a purchase.
Songwen Hua

