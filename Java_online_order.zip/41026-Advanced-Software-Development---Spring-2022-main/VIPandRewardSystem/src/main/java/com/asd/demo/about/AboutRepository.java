package com.asd.demo.about;

import org.springframework.data.repository.CrudRepository;

public interface AboutRepository extends CrudRepository<About, Integer> {
}
