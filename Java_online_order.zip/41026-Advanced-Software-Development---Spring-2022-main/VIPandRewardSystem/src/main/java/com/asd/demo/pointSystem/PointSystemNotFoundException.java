package com.asd.demo.pointSystem;

public class PointSystemNotFoundException extends Throwable{
    public PointSystemNotFoundException(String message) {
        super(message);
    }
}
