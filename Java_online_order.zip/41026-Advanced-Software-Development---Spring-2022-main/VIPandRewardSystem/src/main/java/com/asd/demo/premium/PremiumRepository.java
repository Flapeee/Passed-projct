package com.asd.demo.premium;

import org.springframework.data.repository.CrudRepository;

public interface PremiumRepository extends CrudRepository<Premium, Integer> {
}
