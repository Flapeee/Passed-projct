package com.asd.demo.vipSystem;

import org.springframework.data.repository.CrudRepository;

public interface VipSystemRepository extends CrudRepository<VipSystem, Integer> {
}
