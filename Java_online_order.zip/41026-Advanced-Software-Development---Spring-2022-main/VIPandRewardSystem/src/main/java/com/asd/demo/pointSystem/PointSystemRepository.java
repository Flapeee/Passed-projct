package com.asd.demo.pointSystem;

import org.springframework.data.repository.CrudRepository;

public interface PointSystemRepository extends CrudRepository<PointSystem, Integer> {
}
