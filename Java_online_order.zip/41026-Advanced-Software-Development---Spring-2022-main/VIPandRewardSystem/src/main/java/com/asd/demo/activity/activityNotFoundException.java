package com.asd.demo.activity;

public class activityNotFoundException extends Throwable{
    public activityNotFoundException(String message) {
        super(message);
    }
}
