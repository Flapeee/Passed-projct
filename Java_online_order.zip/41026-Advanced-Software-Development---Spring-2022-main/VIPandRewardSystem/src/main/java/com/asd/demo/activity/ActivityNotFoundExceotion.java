package com.asd.demo.activity;

public class ActivityNotFoundExceotion extends Throwable{
    public ActivityNotFoundExceotion(String message){
        super(message);
    }
}
