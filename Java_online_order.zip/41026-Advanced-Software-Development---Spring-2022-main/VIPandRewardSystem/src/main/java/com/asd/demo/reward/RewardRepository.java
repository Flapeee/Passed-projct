package com.asd.demo.reward;


import org.springframework.data.repository.CrudRepository;

public interface RewardRepository extends CrudRepository<Reward, Integer> {

}
