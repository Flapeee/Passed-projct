package com.group8.monitorfunction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MonitorFunctionApplicationTests {

    @Test
    void contextLoads() {
    }

}
