/**
 * Copyright (C), 2015-2022, XXX有限公司
 * FileName: PaymentManagement
 * Author:   benjamen
 * Date:     2022/9/5 17:38
 * Description:
 * History:
 * <author>          <time>          <version>          <desc>
 * 作者姓名           修改时间           版本号              描述
 */
package com.asd.payment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**

 */
@SpringBootApplication
public class PaymentManagement {
    public static void main(String[] args) {
        SpringApplication.run(PaymentManagement.class, args);
    }
}
