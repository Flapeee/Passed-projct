package com.jingsong.R1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class orderManagement {

    public static void main(String[] args) {
        SpringApplication.run(orderManagement.class, args);
    }

}
