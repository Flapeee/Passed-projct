package com.asd.backened.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.asd.backened.entity.DishFlavor;

public interface DishFlavorService extends IService<DishFlavor> {
}
