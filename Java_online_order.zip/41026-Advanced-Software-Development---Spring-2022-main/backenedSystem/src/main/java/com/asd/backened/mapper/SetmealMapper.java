package com.asd.backened.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.asd.backened.entity.Setmeal;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SetmealMapper extends BaseMapper<Setmeal> {
}
