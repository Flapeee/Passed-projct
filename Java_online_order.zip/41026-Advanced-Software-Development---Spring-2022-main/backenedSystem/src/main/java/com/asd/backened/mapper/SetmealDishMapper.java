package com.asd.backened.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.asd.backened.entity.SetmealDish;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SetmealDishMapper extends BaseMapper<SetmealDish> {
}
